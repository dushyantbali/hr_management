package com.example.hrmanagement_dushyant;

import com.example.hrmanagement_dushyant.admin;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.text.BreakIterator;
import java.util.ResourceBundle;
import  java.sql.*;
public class AdminController {


    public Label welcomeText;

    public Label aa;

    public TextField iid;
    public TextField iname;
    public TextField iemail;
    public TextField ipassword;
    @FXML
    private TableView<admin> tableView;
    @FXML
    private TableColumn<admin, Integer> id;
    @FXML
    private TableColumn<admin, String> name;
    @FXML
    private TableColumn<admin, String> email;
    @FXML
    private TableColumn<admin, Integer> password;

    ObservableList<admin> list = FXCollections.observableArrayList();

    public void initialize(URL url, ResourceBundle resourceBundle) {

        id.setCellValueFactory(new PropertyValueFactory<admin, Integer>("id"));
        name.setCellValueFactory(new PropertyValueFactory<admin, String>("name"));
        email.setCellValueFactory(new PropertyValueFactory<admin, String>("email"));
        password.setCellValueFactory(new PropertyValueFactory<admin, Integer>("password"));

        tableView.setItems(list);
    }

    @FXML
    protected void onHelloButtonClick() {
        list.clear();
        tableView.setItems(list);

        populateTable();
    }


    public void populateTable() {

        // Establish a database connection
        String jdbcUrl = "jdbc:mysql://localhost:3306/dush";
        String dbUser = "root";
        String dbPassword = "";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "SELECT * FROM admin";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            // Populate the table with data from the database
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                String email = resultSet.getString("email");
                int password = resultSet.getInt("password");

                tableView.getItems().add(new admin(id, name, email, password));


            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void backclick(ActionEvent actionEvent) { try {
        Parent secondScene = FXMLLoader.load(getClass().getResource("dashboard.fxml"));

        Stage secondStage = new Stage();
        secondStage.setTitle("back");
        secondStage.setScene(new Scene(secondScene));
        Stage firstSceneStage = (Stage) aa.getScene().getWindow();

        firstSceneStage.close();


        secondStage.show();
    } catch (IOException e) {
        e.printStackTrace();
    }
    }

    public void createclick(ActionEvent actionEvent) {

        String getiid = iid.getText();
        String getname = iname.getText();
        String getemail = iemail.getText();
        String getpassword= ipassword.getText();


        String jdbcUrl = "jdbc:mysql://localhost:3306/dush";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "INSERT INTO `admin`(`name`, `email`, `password`) VALUES ('" + getname + "','" + getemail + "','" + getpassword + "')";
            Statement statement = connection.createStatement();
            statement.execute(query);
            // Populate the table with data from the database

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void deleteclick(ActionEvent actionEvent) {
        String getid = iid.getText();


        String jdbcUrl = "jdbc:mysql://localhost:3306/dush";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "DELETE FROM admin WHERE `id`= '" + getid + "' ";
            Statement statement = connection.createStatement();
            statement.execute(query);
            // Populate the table with data from the database

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewclick(ActionEvent actionEvent) {
        String getid = iid.getText();

        String jdbcUrl = "jdbc:mysql://localhost:3306/dush";
        String dbUser = "root";
        String dbPassword = "";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "SELECT * FROM admin WHERE id=`" + getid + "` ";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            // Populate the table with data from the database
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                String email= resultSet.getString("email");
                int password = resultSet.getInt("password");

                iname.setText(name);
                iemail.setText(email);
                ipassword.setText(String.valueOf(password));
            }} catch (SQLException e) {
                    e.printStackTrace();
                }}

        public void updateclick (ActionEvent actionEvent){
            String getiid = iid.getText();
            String getname = iname.getText();
            String getemail = iemail.getText();
            String getpassword = ipassword.getText();


            String jdbcUrl = "jdbc:mysql://localhost:3306/dush";
            String dbUser = "root";
            String dbPassword = "";
            try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                    dbPassword)) {
                // Execute a SQL query to retrieve data from the database
                String query = "UPDATE `admin` SET `name`='" + getname + "',`email`='" + getemail + "',`password`='" + getpassword + "' WHERE `id` = '" + "getid" + "'";
                Statement statement = connection.createStatement();
                statement.execute(query);
                // Populate the table with data from the database

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
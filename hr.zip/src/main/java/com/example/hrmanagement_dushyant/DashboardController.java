package com.example.hrmanagement_dushyant;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;

public class DashboardController {
    public Label abc;

    public void AdminClick(ActionEvent actionEvent) {
        try {
            Parent secondScene = FXMLLoader.load(getClass().getResource("Admin.fxml"));

            Stage secondStage = new Stage();
            secondStage.setTitle("Admin");
            secondStage.setScene(new Scene(secondScene));
            Stage firstSceneStage = (Stage) abc.getScene().getWindow();

            firstSceneStage.close();


            secondStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void EmployeeClick(ActionEvent actionEvent) {
        try {
            Parent secondScene = FXMLLoader.load(getClass().getResource("Employee.fxml"));

            Stage secondStage = new Stage();
            secondStage.setTitle("Employee");
            secondStage.setScene(new Scene(secondScene));
            Stage firstSceneStage = (Stage) abc.getScene().getWindow();

            firstSceneStage.close();


            secondStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void logoutClick(ActionEvent actionEvent) {
        try {
        Parent secondScene = FXMLLoader.load(getClass().getResource("hello-view.fxml"));

        Stage secondStage = new Stage();
        secondStage.setTitle("Logout");
        secondStage.setScene(new Scene(secondScene));
        Stage firstSceneStage = (Stage) abc.getScene().getWindow();

        firstSceneStage.close();


        secondStage.show();
    } catch (IOException e) {
        e.printStackTrace();
    }
    }

    public void exitClick(ActionEvent actionEvent) {
        try {
            Parent secondScene = FXMLLoader.load(getClass().getResource("hello-view.fxml"));

            Stage secondStage = new Stage();
            secondStage.setTitle("Logout");
            secondStage.setScene(new Scene(secondScene));
            Stage firstSceneStage = (Stage) abc.getScene().getWindow();

            firstSceneStage.close();


            secondStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

